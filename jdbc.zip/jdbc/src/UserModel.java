import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.bean.User;


public class UserModel {
	public static List<User> getListUsers(){
		
		List<User> listusers=new ArrayList<>();
		
		final String DRIVER = "com.mysql.jdbc.Driver";
		final String URL = "jdbc:mysql://127.0.0.1:3306/new_schema?useSSL=false";
		final String USERNAME = "root";
		final String PASSWORD = "P@ssw0rd";
		Statement stmt=null;
		ResultSet rs=null;
			Connection con = null;
			try {
				Class.forName(DRIVER);
				con = DriverManager.getConnection(URL, USERNAME, PASSWORD);
				System.out.println("Connection established");
				String query="select * from user";
				stmt=con.createStatement();
				rs=stmt.executeQuery(query);
				System.out.println(rs);
				while(rs.next()){
					listusers.add(new User(rs.getString("userid"),rs.getString("username"), rs.getString("email")));
				}
				
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(listusers.toString());
			return listusers;
			
		
	}

	public static int addUser(User user) {
		final String DRIVER = "com.mysql.jdbc.Driver";
		final String URL = "jdbc:mysql://127.0.0.1:3306/new_schema?useSSL=false";
		final String USERNAME = "root";
		final String PASSWORD = "P@ssw0rd";
		PreparedStatement stmt=null;
		Connection con = null;
		int i=0;
		try {
			String uid=user.getUserid();
			String uname=user.getUsername();
			String uemail=user.getEmail();
			Class.forName(DRIVER);
			con = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			System.out.println("Connection established");
			String query="Insert into user values(?,?,?)";
			stmt=con.prepareStatement(query);
			stmt.setString(1,uid);
			stmt.setString(2,uname);
			stmt.setString(3,uemail);
			i=stmt.executeUpdate();
			System.out.println("after execution"+i);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
	}

	public static int updateUser(User userupdate) {
		final String DRIVER = "com.mysql.jdbc.Driver";
		final String URL = "jdbc:mysql://127.0.0.1:3306/new_schema?useSSL=false";
		final String USERNAME = "root";
		final String PASSWORD = "P@ssw0rd";
		PreparedStatement stmt=null;
		Connection con = null;
		int i=0;
		try {
			String uid=userupdate.getUserid();
			String uname=userupdate.getUsername();
			String uemail=userupdate.getEmail();
			Class.forName(DRIVER);
			con = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			System.out.println("Connection established");
			String query="update user set username=? , email=? where userid=?";
			stmt=con.prepareStatement(query);
			stmt.setString(1,uname);
			stmt.setString(2,uemail);
			stmt.setString(3,uid);
			System.out.println(stmt);
			i=stmt.executeUpdate();
			System.out.println("after execution after updation"+i);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
	}

	public static int deleteUser(String userid) {
		final String DRIVER = "com.mysql.jdbc.Driver";
		final String URL = "jdbc:mysql://127.0.0.1:3306/new_schema?useSSL=false";
		final String USERNAME = "root";
		final String PASSWORD = "P@ssw0rd";
		PreparedStatement stmt=null;
		Connection con = null;
		int i=0;
		try {
			Class.forName(DRIVER);
			con = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			System.out.println("Connection established");
			String query="delete from user where userid=?";
			stmt=con.prepareStatement(query);
			stmt.setString(1,userid);
			System.out.println(stmt);
			i=stmt.executeUpdate();
			System.out.println("after execution after deletion"+i);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
		
	}

}
