

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.bean.User;

/**
 * Servlet implementation class Homecontroller
 */
@WebServlet("/home")
public class Homecontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("inside the servlet");
		String page=request.getParameter("page");
		page.toLowerCase();
		System.out.println(page);
		switch(page){
		case "home":
			request.getRequestDispatcher("index.jsp").forward(request, response);
			break;
		case "listuser":
			List<User> listuser=UserModel.getListUsers();
			request.setAttribute("listuser", listuser);
			request.getRequestDispatcher("listuser.jsp").forward(request, response);
			break;
		case "adduser":
			request.getRequestDispatcher("adduser.jsp").forward(request, response);
			break;
		case "update":
			request.getRequestDispatcher("updateuser.jsp").forward(request, response);
			break;
		case "delete":
			String userid=request.getParameter("userid");
			int i=UserModel.deleteUser(userid);
			if(i>0){
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}else{
				request.getRequestDispatcher("Error.jsp").forward(request, response);
			}
			break;
		default:
			request.getRequestDispatcher("Error.jsp").forward(request, response);
		}
	}
	
	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String operation=request.getParameter("form");
		System.out.println(operation);
		operation.toLowerCase();
		switch(operation){
		case "adduseroperation":
			User user=new User(request.getParameter("userid"), request.getParameter("username"), request.getParameter("email"));
			int i=UserModel.addUser(user);
			if(i>0){
				request.getRequestDispatcher("addsuccess.jsp").forward(request, response);
			}else{
				request.getRequestDispatcher("Error.jsp").forward(request, response);
			}
			break;
			
		case "updateoperation":
			String userId=request.getParameter("userid");
			System.out.println("userid in updateoperation"+userId);
			User userupdate=new User(request.getParameter("userid"), request.getParameter("username"), request.getParameter("email"));
			int i1=UserModel.updateUser(userupdate);
			if(i1>0){
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}else{
				request.getRequestDispatcher("Error.jsp").forward(request, response);
			}
			break;
		default :
			request.getRequestDispatcher("Error.jsp").forward(request, response);
		}
	}

}
